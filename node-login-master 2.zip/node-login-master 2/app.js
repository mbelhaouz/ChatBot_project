

var http = require('http');
var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser');
var MongoStore = require('connect-mongo')(session);

var io = require('socket.io')(http);
var RiveScript = require("rivescript");
var bot = new RiveScript();

var app = express();
var ensemble=[];
app.locals.pretty = true;
app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/app/server/views');
app.set('view engine', 'pug');
app.use(cookieParser());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(require('stylus').middleware({ src: __dirname + '/app/public' }));
app.use(express.static(__dirname + '/app/public'));

// build mongo database connection url //

process.env.DB_HOST = process.env.DB_HOST || 'localhost'
process.env.DB_PORT = process.env.DB_PORT || 27017;
process.env.DB_NAME = process.env.DB_NAME || 'node-login';

if (app.get('env') != 'live'){
	process.env.DB_URL = 'mongodb://'+process.env.DB_HOST+':'+process.env.DB_PORT;
}	else {
// prepend url with authentication credentials // 
	process.env.DB_URL = 'mongodb://'+process.env.DB_USER+':'+process.env.DB_PASS+'@'+process.env.DB_HOST+':'+process.env.DB_PORT;
}

app.use(session({
	secret: 'faeb4453e5d14fe6f6d04637f78077c76c73d1b4',
	proxy: true,
	resave: true,
	saveUninitialized: true,
	store: new MongoStore({ url: process.env.DB_URL })
	})
);

require('./app/server/routes')(app);

http.createServer(app).listen(app.get('port'), function(){
	console.log('Express server listening on port ' + app.get('port'));
});





/*---------------------------------------Partie BOT .JS--------------------------------------*/


var urlencodedParser = bodyParser.urlencoded({ extended: false })




bot.loadDirectory("brain");
bot.sortReplies();
app.use(express.static('assets'));


/* **************** CREATE BOT *************

* Param : PORT

*/




function create_bot(Port,brain){ 



	var s = express();
	var https = require('http').Server(s);
	var iop = require('socket.io')(https);
		var bots = new RiveScript();

https.listen(Port, function () {
  console.log("New Chatbot created ");
});


console.log('brain/'+brain);

bots.loadFile("brain/"+brain);
//bots.loadDirectory("brain");

console.log('done');

s.use(express.static('assets'));

s.get('/', function (req, res) {
  res.sendFile(__dirname + '/index.html');
});


//_______//

console.log('start iop.on socket ');

iop.on('connection', function (socket) {
  socket.on('chat message', function (msg) {
	bots.sortReplies();

    // And now we're free to get a reply from the brain!
    console.log("Input received: " + msg);
    var reply = bots.reply("local-user", msg);
    iop.emit('chat message', reply);
    console.log("Bot response: " + reply);
  });
});



//____________
 console.log('bot created');

var idbot = [https,Port];

ensemble.push(idbot);
console.log('added to ensemble');
console.log(ensemble);


}







/* **************** DELETE BOT *************

* Param : PORT

*/

function delete_bot(Port){


var cpt;

console.log('boucle commencee');
console.log(Port.port);
console.log(ensemble[0][1].port);
for (cpt = 0; cpt < ensemble.length; cpt++) {


	if(ensemble[cpt][1].port==Port.port){



		ensemble[cpt][0].close();
		ensemble[cpt]=[null,0];



}
  



}

}


/* ************** EDIT BRAIN **********

* Param : PORT, Brain File Name ( Name.rive )

*/


function edit_brain(PortetBrain){


delete_bot(PortetBrain); // Supprime le chatbot

console.log('bot deleted');

create_bot(PortetBrain,PortetBrain.brain);

console.log('brain edited');


console.log(ensemble);



}




app.post('/Host0',urlencodedParser, function (req, res) {
console.log(req.body);


res.writeHead(302, {
    Location: 'http://localhost:'+req.body.invisible0
});
res.end();

  

});

app.post('/Host1', urlencodedParser,function (req, res) {

console.log(req.body);

res.writeHead(302, {
    Location: 'http://localhost:'+req.body.invisible1
});
res.end();

  

});

app.post('/Host2',urlencodedParser, function (req, res) {
console.log(req.body);


res.writeHead(302, {
    Location: 'http://localhost:'+req.body.invisible2
});
res.end();

  

});

app.post('/Host3',urlencodedParser, function (req, res) {

console.log(req.body);

res.writeHead(302, {
    Location: 'http://localhost:'+req.body.invisible3
});
res.end();

  

});

app.post('/Host4',urlencodedParser, function (req, res) {

console.log(req.body);

res.writeHead(302, {
    Location: 'http://localhost:'+req.body.invisible4
});
res.end();

  

});
app.get('/', function (req, res) {


  res.sendFile(__dirname + '/index.html');

  

});

app.post('/init', function (req, res) {


  res.sendFile(__dirname + '/index_2.html');




});

app.post('/Tableau', function (req, res) {


  res.sendFile(__dirname + '/index_2.html');




});
app.get('/home', function (req, res) {


  res.sendFile(__dirname + '/index_2.html');



});

app.post('/addbot',urlencodedParser,function (req, res) {

console.log("A new Chat bot has been added check with this port :");
console.log(req.body);
create_bot(req.body,"admin.rive");

 res.sendFile(__dirname + '/index_2.html');




});
app.post('/Deletebot',urlencodedParser,function (req, res) {

console.log("the Chat bot has been deleted check with this port :");
console.log(req.body);


delete_bot(req.body);

  res.sendFile(__dirname + '/index_2.html');

});


app.post('/editbrain',urlencodedParser,function (req, res) {

console.log("the Brain will change :");
console.log(req.body);



edit_brain(req.body);

  res.sendFile(__dirname + '/index_2.html');




});










